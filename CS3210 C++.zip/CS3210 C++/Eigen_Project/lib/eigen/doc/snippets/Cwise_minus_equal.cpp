Array3d v(1,2,3);
v -= 5;
cout << v << endl;
